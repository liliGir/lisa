#include <string.h>
int main(int argc, char** argv)
{
    char buf[16];
    memset(buf, 'A', 65);
}